from django.shortcuts import render, redirect
from django.contrib import auth
from django.http import JsonResponse
from django.core import serializers
from app.models import Invoice, UserPorfile
import json


def login_required(func):

    def wrapper(request, *args, **kwargs):
        session = request.session
        if 'username' in session:
            return func(request, *args, **kwargs)
        else:
            return redirect('/login/')

    return wrapper


def login(request):
    result = {'status': 1, 'msg': None, 'data': None}

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)

        if user:
            auth.login(request, user)
            request.session['username'] = username
            result['data'] = {'username': username, 'url': '/'}
        else:
            result['status'], result['msg'] = 0, 'username ou password incorrecte！'

        return JsonResponse(result)

    return render(request, 'login.html')


@login_required
def logout(request):
    try:
        auth.logout(request)
    except:
        pass

    return redirect('/login/')


@login_required
def index(request):
    return render(request, 'index.html', {'username': request.session['username']})


def api_invoice(request):
    result = {'status': 1, 'msg': None, 'data': None}
    try:
        if request.method == 'POST':
            data = request.POST.dict()
            username = data.pop('username')
            password = data.pop('password')
            user = auth.authenticate(username=username, password=password)
            if user:
                date = '20' + data.pop('date').replace('/', '-')
                data['date'] = date
                data['user'] = UserPorfile.objects.get(user__username=username)
                invoice = Invoice.objects.filter(facture=data['facture'])
                if invoice:
                    invoice = invoice[0]
                    invoice.__dict__.update(**data)
                else:
                    invoice = Invoice(**data)
                    invoice.save()
            else:
                result['status'] = 0
                result['msg'] = 'failed！'
    except Exception as e:
        result['status'] = 0
        result['msg'] = str(e)

    return JsonResponse(result)
