from django.db import models
from django.contrib.auth.models import User


class UserPorfile(models.Model):
    '''user list'''
    user = models.OneToOneField(User, on_delete='models.CASCADE')

    def __str__(self):
        return self.user.username

    class Meta:
        verbose_name_plural = 'user list'


class Invoice(models.Model):
    facture = models.CharField(max_length=20, unique=True, verbose_name='facture')
    client = models.CharField(max_length=50, default='', blank=True, null=True)
    objet = models.CharField(max_length=50, default='', blank=True, null=True)
    ref = models.CharField(max_length=20, default='', blank=True, null=True)
    date = models.DateField(blank=True, null=True)
    montant_tva = models.DecimalField(max_digits=5, decimal_places=2)
    total_ttc = models.DecimalField(max_digits=8, decimal_places=2)
    user = models.ForeignKey('UserPorfile', on_delete='models.CASCADE', blank=True, null=True)
    add_date = models.DateTimeField(auto_now_add=True)
    update_date = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.facture

    class Meta:
        verbose_name_plural = 'facture'
