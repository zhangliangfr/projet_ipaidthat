import requests
from bs4 import BeautifulSoup
import re


requests.packages.urllib3.disable_warnings()


class Factomos(object):
    def __init__(self):
        self.session = requests.Session()
        self.cookies = ''

    def login(self):
        email = "zhangliang_fr@hotmail.com"
        password = "Azer1234!"

        r = self.session.get(
            url='https://app.factomos.com/connexion',
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 "
                              "(KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36",
            },
            verify=False,
        )
        '''simuler la connection avec navigateur'''
        cookies = []
        if r.status_code == 200 and r.ok:
            for item in r.cookies.items():
                cookies.append('%s=%s' % item)
            self.cookies = '; '.join(cookies)

        r = self.session.post(
            url='https://app.factomos.com/controllers/app-pro/login-ajax.php',
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 "
                              "(KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36",
                "Cookie": self.cookies,
            },
            data={
                "appAction": "login",
                "email": email,
                "password": password,
            },
            verify=False,
        )

        return r.ok if r.json()['error']['code'] == 0 else False


    def crawl(self):
        r = self.session.get(
            url='https://app.factomos.com/mes-factures',
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 "
                              "(KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36",
                "Cookie": self.cookies
            },
            verify=False,
        )

        if r.ok and r.status_code == 200: self.parse_result(r)

    def parse_result(self, response):
        soup = BeautifulSoup(response.text, 'html.parser')
        tbody = soup.find('tbody', id='invoiceListBody')
        trs = tbody.find_all('tr')
        for tr in trs:
            tds = tr.find_all('td')
            item = {}
            item['FACTURE'] = tds[1].text.strip().replace('\xa0', ' ')
            item['CLIENT'] = tds[2].text.strip()
            item['OBJET'] = tds[3].text.strip()
            item['REF'] = tds[4].text.strip()
            item['DATE'] = tds[5].text.strip()
            # item['TOTAL_HT'] = tds[6].text.strip().replace('\xa0', ' ')
            # item['MONTANT_TVA'] = tds[7].text.strip().replace('\xa0', ' ')
            # item['TOTAL_TTC'] = tds[8].text.strip().replace('\xa0', ' ')
            item['MONTANT_TVA'] = re.search(r'^(.*?)(?!\xa0)(.*?)$', tds[7].text).group()
            item['TOTAL_TTC'] = re.search(r'^(.*?)(?!\xa0)(.*?)$', tds[8].text).group()
            # item['ACOMPTE'] = tds[9].text.strip().replace('\xa0', ' ')
            # item['EN_ATTENTE'] = tds[10].text.strip().replace('\xa0', ' ')

            data = {key.lower(): val for key, val in item.items()}
            data['username'], data['password'] = 'admin', '123456'
            url = 'http://127.0.0.1:8000/api/invoice/'
            r = requests.post(url, data=data)
            if r.json()['status'] == 1:
                print('%s collection et envoyer avec succès' % item['FACTURE'])

    def start(self):
        if self.login():
            print('se connecter réussit, commence à collecter！')
            self.crawl()
        else:
            print('échec de la connection！')


if __name__ == '__main__':
    fa = Factomos()
    fa.start()
