from django.contrib import admin
from app import models

admin.site.register(models.UserPorfile)
admin.site.register(models.Invoice)
